DROP DATABASE IF EXISTS go_peli;
CREATE DATABASE go_peli;
use go_peli;

DROP TABLE IF EXISTS lecturer_addition;
DROP TABLE IF EXISTS accomplish;
DROP TABLE IF EXISTS enroll;
DROP TABLE IF EXISTS plays;
DROP TABLE IF EXISTS points;
DROP TABLE IF EXISTS board;
DROP TABLE IF EXISTS levels;
DROP TABLE IF EXISTS receives;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS question;
DROP TABLE IF EXISTS player;
DROP TABLE IF EXISTS lecturer;

DROP TABLE IF EXISTS course;





CREATE TABLE lecturer(
	 lect_id varchar(55),
	 lect_passwd varchar(55),
	 primary key(lect_id)
 )ENGINE=InnoDB;



CREATE TABLE course(
	course_id varchar(55),
	course_name varchar(55),
	course_desc varchar(55),
	lect_id varchar(55),
	PRIMARY KEY (course_id),
	FOREIGN Key(lect_id) REFERENCES lecturer(lect_id) ON UPDATE CASCADE ON DELETE CASCADE
)ENGINE=InnoDB;




CREATE TABLE player(
	user_id varchar(55),
	password varchar(55),
	PRIMARY KEY(user_id)
)ENGINE=InnoDB;



CREATE TABLE topic(
	topic_id int,
	topic_name varchar(55),
	course_id varchar(55),
	primary key (course_id,topic_id),
	FOREIGN key(course_id) REFERENCES course(course_id) ON UPDATE CASCADE on DELETE CASCADE,
	Unique(topic_name),
	unique(topic_id)
)ENGINE=InnoDB;


CREATE TABLE question(
	question_id int AUTO_INCREMENT,
	question LONGTEXT,
	hints LONGTEXT,
	solution LONGTEXT,
	test_cases LONGTEXT,
	test_case_solution LONGTEXT,
	topic_name varchar(55),
	PRIMARY KEY(question_id,topic_name),
	FOREIGN KEY(topic_name) REFERENCES topic(topic_name) ON UPDATE CASCADE ON DELETE CASCADE
)ENGINE=InnoDB;

CREATE TABLE items(
	items_name varchar(55),
	topic_name varchar(55),
	PRIMARY KEY(items_name)
)ENGINE=InnoDB;

CREATE TABLE receives(
	items_name varchar(55),
	user_id varchar(55),
	topic_name varchar(55),
	FOREIGN KEY (user_id) REFERENCES player(user_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY(items_name)REFERENCES items(items_name) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY(topic_name) REFERENCES topic(topic_name) ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY(user_id,items_name,topic_name)
)ENGINE=InnoDB;


CREATE TABLE levels(
	levels_num int,
	topic_name varchar(55),
	FOREIGN KEY(topic_name) REFERENCES topic(topic_name) ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY(levels_num,topic_name)
)ENGINE=InnoDB;


CREATE TABLE board(
	user_id varchar(55),
	levels_num int,
	score int,
	FOREIGN KEY(user_id) REFERENCES player(user_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (levels_num) REFERENCES levels(levels_num) ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY Key(user_id,levels_num)
)ENGINE=InnoDB;


CREATE TABLE points(
	grade varchar(55),
	points double,
	PRIMARY KEY(grade)
	-- remember to calculate the grade
)ENGINE=InnoDB;

CREATE TABLE plays(
	question_id int,
	player_sol LONGTEXT,
	completed BOOLEAN,
	play_time TIME,
	test_case_correct int,
	soln_level varchar(5),
	qpoints int,
	user_id varchar(55),
	FOREIGN KEY (question_id) REFERENCES question(question_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY(user_id) REFERENCES player(user_id) ON UPDATE CASCADE ON DELETE CASCADE
)ENGINE=InnoDB;


CREATE TABLE enroll(
	user_id varchar(55),
	course_id varchar(55),
	FOREIGN KEY (user_id) REFERENCES player(user_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (course_id) REFERENCES course(course_id) ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY(course_id,user_id)
)ENGINE=InnoDB;

CREATE TABLE accomplish(
	user_id varchar(55),
	topic_id int,
	FOREIGN KEY (user_id) REFERENCES player(user_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY(topic_id) REFERENCES topic(topic_id) ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY(user_id,topic_id)
)ENGINE=InnoDB;

CREATE TABLE lecturer_addition(
	question LONGTEXT,
	lect_solutions LONGTEXT,
	lect_test_case LONGTEXT,
	lect_test_case_solution LONGTEXT
)ENGINE=InnoDB;


INSERT INTO player(user_id,password) VALUES('978087543','annajohn');
INSERT INTO player(user_id,password)VALUES('97804737','jonahpusey98');
INSERT INTO player(user_id,password)VALUES('97803985','fiercegoddess98');
INSERT INTO player(user_id,password)VALUES('97803732','techisnotme123');
INSERT INTO player(user_id,password)VALUES('97807294','raspberrypi1010');
INSERT INTO player(user_id,password)VALUES('978029490','cuntyanna');
INSERT INTO player(user_id,password)VALUES('97803839','mariojose');
INSERT INTO player(user_id,password)VALUES('978092049','hdhowdmsam');
INSERT INTO player(user_id,password)VALUES('97807920','novascotia1054');
INSERT INTO player(user_id,password)VALUES('97805466','orangejuice');
INSERT INTO player(user_id,password)VALUES('97803455','lettuceprey');
INSERT INTO player(user_id,password)VALUES('97804655','hbdshadows18');
INSERT INTO player(user_id,password)VALUES('97806666','trevjohn98');


-- INSERT INTO player(user_id,password)VALUES('gopeli','GoPeli');
-- username:gopeli password:GoPeli

-- SERVER add 198.121.101.247


INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10005611','anacondapy');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10005622','disgustingmofo');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10005633','davabarnia');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10005788','joanofark');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10005799','danielletraboja');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10004596','uwichapel');
INSERT INTO lecturer(lect_id,lect_passwd)VALUES('10008991','treeoflife');


INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('COMP1126','Intro to Computing I','Learning Python I','10005611');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('COMP1127','Intro to Computing II','Learning Python I','10005622');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('COMP1161','Intro to Object-Oriented Programming','Learning Java','10005633');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('COMP2201','Discrete Mathematics for Computer Science','Probability Distributions, Permutations & Combinations, etc','10005611');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('INFO2180','Web Programming','Front and Back End Development','10005611');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('COMP2211','Discrete Mathematics for Computer Science,','Probability Distributions,Permutations & Combinations,etc','10005622');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('INFO2180','Web Programming','Front and Back End Development','10005788');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('COMP1161','Intro to Object-Oriented Programming','Learning Java','10005799');

INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('COMP1126','Intro to Computing I','Learning Python I','10004596');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('COMP1126','Intro to Computing II','Learning Python II','10004596');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES ('INFO2180','Web Programming','Front and Back End Developement','10005611');

INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('INFO2180','Web Programming','Front and Back Developement','10008991');
INSERT INTO course(course_id,course_name,course_desc,lect_id)VALUES('COMP2211','Discrete Mathematics for Computer Science','10008991');







INSERT INTO enroll(user_id,course_id) VALUES('978087543','COMP1126');
INSERT INTO enroll(user_id,course_id) VALUES('978087543','COMP1127');
INSERT INTO enroll(user_id,course_id) VALUES('978087543','COMP1161');
INSERT INTO enroll(user_id,course_id) VALUES('978087543','INFO2180');
INSERT INTO enroll(user_id,course_id) VALUES('978029490','COMP1126');
INSERT INTO enroll(user_id,course_id) VALUES('97803839','COMP1127');
INSERT INTO enroll(user_id,course_id) VALUES('97807920','COMP1161');
INSERT INTO enroll(user_id,course_id) VALUES('978092049','COMP1126');
INSERT INTO enroll(user_id,course_id)VALUES('97807920','COMP1126');
INSERT INTO enroll(user_id,course_id)VALUES('97805466','COMP1127');
INSERT INTO enroll(user_id,course_id)VALUES('97803455','COMP1126');
INSERT INTO enroll(user_id,course_id)VALUES('97804655','COMP1127');
INSERT INTO enroll(user_id,course_idVALUES('97806666','COMP1127');


INSERT INTO topic(topic_id,topic_name,course_id) VALUES(1001,'Intro to Functions','COMP1126');
INSERT INTo topic(topic_id,topic_name,course_id)VALUES(1002,'Python DataTypes','COMP1126');
INSERT INTO topic(topic_id,topic_name,course_id)VALUES(1003,'Python Loop Structures', 'COMP1126');
INSERT INTO topic(topic_id,topic_name,course_id)VALues(1004,'Recursion','COMP1126');
INSERT INTO topic(topic_id, topic_name,course_id)VALUES(1005,'Higher Order Functions','COMP1126');
INSERT INTO topic(topic_id,topic_name,course_id) VALUES(2001,'Abstract Data Types','COMP1127');
INSERT INTO topic(topic_id,topic_name,course_id)VALUES(3008,'GUI Programming in Java','COMP1161');


INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',1001);
INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',1002);
INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',1003);
INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',1004);
INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',1005);
INSERT INTO accomplish(user_id, topic_id)VALUES('978087543',2001);
INSERT INTO accomplish(user_id,topic_id)VALUES('978029490',1004);
INSERT INTO accomplish(user_id,topic_id)VALUES('978087543',2001);
INSERT INTO accomplish(user_id,topic_id)VALUES('978029490',1004);


INSERT INTO points(grade, points) VALUES('90-100',4.3);
INSERT INTO points(grade, points) VALUES('80-89',4.0);
INSERT INTO points(grade, points) VALUES('75-79',3.7);
INSERT INTO points(grade, points) VALUES('70-74',3.3);
INSERT INTO points(grade, points) VALUES('65-69',3.0);
INSERT INTO points(grade, points) VALUES('60-64',2.7);

INSERT INTO points(grade, points) VALUES('55-59',2.3);
INSERT INTO points(grade, points) VALUES('50-54',2.0);
INSERT INTO points(grade, points) VALUES('45-49',1.7);
INSERT INTO points(grade, points) VALUES('40-44',1.3);
INSERT INTO points(grade,points)  VALUES('0-39',0.0);

INSERT INTO items(items_name,topic_name) VALUES('Tie','Intro to Functions');
INSERT INTO items(items_name,topic_name) VALUES('Jacket', 'Python DataTypes'); 
INSERT INTO items(items_name,topic_name) VALUES('Shoes','Python Loop Structures');
INSERT INTO items(items_name,topic_name) VALUES('Cap', 'Recursion');
INSERT INTO items(items_name,topic_name) VALUES('Gown','Higher Order Functions');
INSERT INTO items(items_name,topic_name) VALUES('Badge', 'Abstract Data Types');
INSERT INTO items(items_name,topic_name) VALUES('Socks','GUI Programming in Java');

INSERT INTO levels(levels_num,topic_name) VALUES(100,'Intro to Functions');
INSERT INTO levels(levels_num,topic_name) VALUES(101, 'Python DataTypes');
INSERT INTO levels(levels_num,topic_name) VALUES(102, 'Recursion');



-- UPDATE plays set completed= CASE WHEN(end_time NOT NULL) THEN completed="True" ELSE completed="False";

SELECT * FROM enroll; --show all students that are enrolled in the course game--
SELECT * FROM enroll WHERE course_id='COMP1126'; --show all the students that are enrolled in COMP1126 course game--
SELECT * FROM enroll WHERE course_id='COMP1127'; --show all the students that are enrolled in COMP1127 course game--
SELECT * FROM enroll WHERE course_id='COMP1161';--show all the students that are enrolled in COMP1161 course game--
SELECT * FROM enroll WHERE course_id='INFO2180';--show all the students that are enrolled in INFO2180 course game--

SELECT COUNT(user_id),course_id FROM enroll GROUP by course_id; --shows the numbers of students enrolled in each course--
 

SELECT * FROM player;

-- --Queries

 














