import sys, tempfile, operator, traceback, StringIO
import StringIO

class functions:

    # def add(self, code):
    #     str(num1)
    #     try:
    #         c = 2 + num1
    #         return c
    #     except:
    #         exc_type, exc_value, exc_traceback = sys.exc_info()
    #         return repr(traceback.format_exception(exc_type, exc_value,
    #                                                exc_traceback))

    def fun(self, code):
        try:
            print code
            exec(code)
            print(test())

            return 'ok'
            # tem = tempfile.TemporaryFile()
            # tem.write(code)
            # tem.seek(0)
            # result = StringIO.StringIO()
            #
            # sys.stdout = result
            # # if sys.stdout is None:
            # #     stdout = StringIO.StringIO()
            #
            #
            # exec(tem.read())
            # sys.stdout = sys.__stdout__
            #
            # s = result.getvalue()
            # if s:
            #     print "output:\n%s" % s
            #     return s
            # result.close()


        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            return repr(traceback.format_exception(exc_type, exc_value,
                                                   exc_traceback))

    # def test(self, code):
    #     return 0