from wtforms import StringField, PasswordField, validators
from flask_wtf import FlaskForm


class MyForm(FlaskForm):
    username = StringField('Username', [validators.Length(min=4, max=25)])
    password = PasswordField('Password', [ validators.DataRequired()])
